#!/usr/bin/env python3
# app.py -- FastAPI + YOLOv8 + OCR Optimizado para detección de placas
# Requiere: fastapi uvicorn ultralytics easyocr opencv-python-headless pillow numpy python-multipart pytesseract

import os
import re
import logging
import base64
from pathlib import Path
from typing import List, Optional, Dict, Any
from fastapi import FastAPI, File, UploadFile, Form, Request
from fastapi.middleware.cors import CORSMiddleware
from ultralytics import YOLO
import cv2
import numpy as np
import pytesseract

BASE_DIR = Path(__file__).resolve().parents[2]

# -------------------------
# Config / Logging
# -------------------------
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("yolo-plates")

_default_model = BASE_DIR / "models" / "best.pt"
if not _default_model.exists() and (BASE_DIR / "best.pt").exists():
    _default_model = BASE_DIR / "best.pt"

MODEL_PATH = Path(os.getenv("MODEL_PATH", str(_default_model)))
OCR_LANGS = os.getenv("OCR_LANGS", "eng").split(",")
CONF_THRESH = float(os.getenv("CONF_THRESH", 0.20))
IOU_THRESH = float(os.getenv("IOU_THRESH", 0.45))
RETURN_IMAGE = True

if os.getenv("TESSERACT_CMD"):
    pytesseract.pytesseract.tesseract_cmd = os.getenv("TESSERACT_CMD")

# -------------------------
# App init
# -------------------------
app = FastAPI(title="YOLOv8 + OCR Optimizado - Detector de Placas")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# -------------------------
# Cargar modelo
# -------------------------
logger.info("🔹 Cargando modelo YOLOv8 desde %s ...", MODEL_PATH)
model = YOLO(str(MODEL_PATH))
logger.info("✅ Modelo YOLOv8 cargado correctamente.")

# -------------------------
# Helpers de Filtrado y Preprocesamiento
# -------------------------
PLATE_REGEX = re.compile(r'([A-Z]{2,4}\d{2,4}[A-Z]?)')

def clean_and_correct_plate(text: str) -> Optional[str]:
    """Limpia el texto sin adivinar ni modificar caracteres (retorna exactamente lo leído)."""
    cleaned = re.sub(r"[^A-Za-z0-9]", "", text).upper()
    if not cleaned or len(cleaned) < 4 or len(cleaned) > 8:
        return None

    # Si hay una coincidencia con el formato de placa dentro del texto, extraerla
    match = PLATE_REGEX.search(cleaned)
    if match:
        return match.group(1)

    # Retornar exactamente el texto leído de 4 a 8 caracteres sin adivinar ni cambiar letras por números
    return cleaned


def is_valid_plate_box(box: np.ndarray, frame_shape: tuple) -> bool:
    """Filtra detecciones falsas según relación de aspecto (ancho/alto) y tamaño mínimo."""
    x1, y1, x2, y2 = box
    w = x2 - x1
    h = y2 - y1
    if w < 15 or h < 8:
        return False
    
    aspect_ratio = w / float(h)
    if aspect_ratio < 1.1 or aspect_ratio > 6.0:
        return False

    return True


def preprocess_roi_variants(roi_bgr: np.ndarray) -> List[np.ndarray]:
    """Genera variaciones de la imagen ROI (contraste, nitidez, binarización) para maximizar precisión del OCR."""
    if roi_bgr is None or roi_bgr.size == 0:
        return []

    variants = []
    h, w = roi_bgr.shape[:2]

    scale = 1.0
    if w < 180:
        scale = 200.0 / w
    elif w > 800:
        scale = 800.0 / w

    if abs(scale - 1.0) > 0.05:
        new_w, new_h = max(1, int(w * scale)), max(1, int(h * scale))
        resized = cv2.resize(roi_bgr, (new_w, new_h), interpolation=cv2.INTER_CUBIC)
    else:
        resized = roi_bgr

    variants.append(cv2.cvtColor(resized, cv2.COLOR_BGR2RGB))

    gray = cv2.cvtColor(resized, cv2.COLOR_BGR2GRAY)
    kernel_sharpen = np.array([[0, -1, 0], [-1, 5, -1], [0, -1, 0]])
    sharpened = cv2.filter2D(gray, -1, kernel_sharpen)
    variants.append(sharpened)

    clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8, 8))
    gray_clahe = clahe.apply(gray)
    variants.append(gray_clahe)

    _, binary_otsu = cv2.threshold(gray_clahe, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    variants.append(binary_otsu)

    return variants


def ocr_read_text_from_roi(roi_bgr: np.ndarray) -> Optional[str]:
    """Ejecuta OCR sobre variantes de la ROI y devuelve la lectura real exacta sin adivinar."""
    try:
        if roi_bgr is None or roi_bgr.size == 0:
            return None

        variants = preprocess_roi_variants(roi_bgr)
        candidates = []

        for img in variants:
            gray_img = img if len(img.shape) == 2 else cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

            for psm in ["--psm 7 --oem 3", "--psm 8 --oem 3", "--psm 6 --oem 3"]:
                try:
                    raw_text = pytesseract.image_to_string(gray_img, config=psm, lang=OCR_LANGS[0])
                except Exception:
                    raw_text = ""

                cleaned = clean_and_correct_plate(raw_text)
                if cleaned:
                    candidates.append(cleaned)

        if candidates:
            candidates.sort(key=lambda c: (PLATE_REGEX.search(c) is not None, len(c)), reverse=True)
            return candidates[0]

        return None

    except Exception as e:
        logger.exception("Error en OCR: %s", e)
        return None


def crop_roi_with_padding(frame: np.ndarray, box: np.ndarray, pad_pct: float = 0.08) -> np.ndarray:
    """Extrae la sub-imagen agregando margen porcentual."""
    h, w = frame.shape[:2]
    x1, y1, x2, y2 = map(int, box)
    box_w = x2 - x1
    box_h = y2 - y1

    pad_w = int(box_w * pad_pct)
    pad_h = int(box_h * pad_pct)

    x1_pad = max(0, x1 - pad_w)
    y1_pad = max(0, y1 - pad_h)
    x2_pad = min(w, x2 + pad_w)
    y2_pad = min(h, y2 + pad_h)

    return frame[y1_pad:y2_pad, x1_pad:x2_pad].copy()


def image_to_base64_jpg(img_bgr: np.ndarray) -> str:
    _, buffer = cv2.imencode('.jpg', img_bgr, [int(cv2.IMWRITE_JPEG_QUALITY), 88])
    return base64.b64encode(buffer).decode('utf-8')


# -------------------------
# Endpoints
# -------------------------
@app.get("/")
def home():
    return {"message": "YOLOv8 + OCR Optimizado server running", "model": str(MODEL_PATH)}


@app.post("/predict/")
@app.post("/predict")
@app.post("/api/predict")
async def predict(
    file: Optional[UploadFile] = File(None),
    image_base64: Optional[str] = Form(None)
):
    try:
        logger.info("📩 Petición recibida en /predict/")

        if file is not None and hasattr(file, "read"):
            contents = await file.read()
            nparr = np.frombuffer(contents, np.uint8)
        elif image_base64:
            if image_base64.startswith("data:image"):
                image_base64 = image_base64.split(",")[1]
            image_base64 = image_base64.strip()
            try:
                img_data = base64.b64decode(image_base64 + "===")
            except Exception as e:
                logger.error("❌ Base64 inválido: %s", e)
                return {"error": "Base64 inválido o corrupto."}
            nparr = np.frombuffer(img_data, np.uint8)
        else:
            return {"error": "No se recibió ninguna imagen"}

        frame = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        if frame is None:
            return {"error": "No se pudo decodificar la imagen"}

        logger.info("🧠 Procesando imagen con YOLOv8 (conf=%.2f, iou=%.2f)...", CONF_THRESH, IOU_THRESH)
        results = model.predict(source=frame, conf=CONF_THRESH, iou=IOU_THRESH, verbose=False)
        if not results:
            return {"placas": [], "num_placas": 0, "details": [], "image": None, "success": True, "message": "Sin detecciones"}

        r = results[0]
        boxes = r.boxes.xyxy.cpu().numpy() if len(r.boxes) > 0 else np.array([])
        confs = r.boxes.conf.cpu().numpy() if len(r.boxes) > 0 else np.array([])
        clss = r.boxes.cls.cpu().numpy() if len(r.boxes) > 0 else np.array([])

        placas_detectadas: List[str] = []
        detalles: List[Dict[str, Any]] = []

        for i, box in enumerate(boxes):
            if not is_valid_plate_box(box, frame.shape):
                continue

            x1, y1, x2, y2 = map(int, box)
            cls_id = int(clss[i]) if len(clss) > i else 0
            label = model.names[cls_id] if cls_id < len(model.names) else "placa"
            conf = float(confs[i]) if len(confs) > i else 0.0

            roi = crop_roi_with_padding(frame, box, pad_pct=0.08)
            text_detected = ocr_read_text_from_roi(roi)

            display_text = text_detected if text_detected else f"PLACA_{i+1}"
            if display_text not in placas_detectadas:
                placas_detectadas.append(display_text)

            detalles.append({
                "caja": [x1, y1, x2, y2],
                "confianza_yolo": round(conf, 4),
                "texto_ocr": text_detected,
                "clase": label
            })

            cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
            cv2.putText(frame, display_text, (x1, max(30, y1 - 10)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 255), 2)
            cv2.putText(frame, f"{label} {conf:.2f}", (x1, y2 + 20),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 200, 0), 2)

        img_b64 = image_to_base64_jpg(frame) if RETURN_IMAGE else None

        logger.info("✅ Placas detectadas: %s", placas_detectadas)

        return {
            "success": True,
            "placas": placas_detectadas,
            "num_placas": len(placas_detectadas),
            "details": detalles,
            "image": img_b64,
            "message": "OK" if placas_detectadas else "No se detectaron placas válidas"
        }

    except Exception as e:
        logger.exception("Error en /predict/: %s", e)
        return {"error": str(e)}


@app.post("/predict_json/")
@app.post("/predict_json")
@app.post("/api/predict_json")
async def predict_json(request: Request):
    try:
        body = await request.json()
        image_base64 = body.get("image_base64")
        if not image_base64:
            return {"error": "No se recibió ninguna imagen"}

        if image_base64.startswith("data:image"):
            image_base64 = image_base64.split(",")[1]
        image_base64 = image_base64.strip()
        img_data = base64.b64decode(image_base64 + "===")
        nparr = np.frombuffer(img_data, np.uint8)
        frame = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

        if frame is None:
            return {"error": "No se pudo decodificar la imagen"}

        results = model.predict(source=frame, conf=CONF_THRESH, iou=IOU_THRESH, verbose=False)
        if not results:
            return {"placas": [], "num_placas": 0, "details": [], "image": None, "success": True, "message": "Sin detecciones"}

        r = results[0]
        boxes = r.boxes.xyxy.cpu().numpy() if len(r.boxes) > 0 else np.array([])
        clss = r.boxes.cls.cpu().numpy() if len(r.boxes) > 0 else np.array([])
        confs = r.boxes.conf.cpu().numpy() if len(r.boxes) > 0 else np.array([])

        placas_detectadas = []
        detalles = []

        for i, box in enumerate(boxes):
            if not is_valid_plate_box(box, frame.shape):
                continue

            x1, y1, x2, y2 = map(int, box)
            cls_id = int(clss[i]) if len(clss) > i else 0
            label = model.names[cls_id] if cls_id < len(model.names) else "placa"
            conf = float(confs[i]) if len(confs) > i else 0.0

            roi = crop_roi_with_padding(frame, box, pad_pct=0.08)
            text_detected = ocr_read_text_from_roi(roi)

            display_text = text_detected if text_detected else f"PLACA_{i+1}"
            if display_text not in placas_detectadas:
                placas_detectadas.append(display_text)

            detalles.append({
                "caja": [x1, y1, x2, y2],
                "confianza_yolo": round(conf, 4),
                "texto_ocr": text_detected,
                "clase": label
            })

            cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
            cv2.putText(frame, display_text, (x1, max(30, y1 - 10)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 255), 2)
            cv2.putText(frame, f"{label} {conf:.2f}", (x1, y2 + 20),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 200, 0), 2)

        img_b64 = image_to_base64_jpg(frame) if RETURN_IMAGE else None

        return {
            "success": True,
            "placas": placas_detectadas,
            "num_placas": len(placas_detectadas),
            "details": detalles,
            "image": img_b64,
            "message": "OK" if placas_detectadas else "No se detectaron placas válidas"
        }

    except Exception as e:
        logger.exception("Error en /predict_json/: %s", e)
        return {"error": str(e)}


if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("PORT", 8080))
    logger.info("🚀 Iniciando servidor en 0.0.0.0:%s", port)
    uvicorn.run(app, host="0.0.0.0", port=port, reload=False)
  
